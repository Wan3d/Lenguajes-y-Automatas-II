using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

static void Main(string[] args)
{
  int x = 10;
  do{
    x+= 2;
  } while(x < 13 );
}
  

  /*int x26 = 200;

  char hola;

  float adio;

  x26++;

  x26--;*/

  /*do {
    x26 = x26 + 1;
  } while (x26 < 211);
  */

  /*if (1 > 2){
    x26 = 100;
  }

  if (1 >= 2){
  x26 = 100;
  }

  if (2 < 1){
    x26 = 100;
  }

  if (2 <= 1){
    x26 = 100;
  }

  if (1 == 2){
    x26 = 100;
  }

  if (1 != 2){
    x26 = 300;
  }*/

  /*if ((3 + 5) * 8 - (10 - 4) / 2 == 61){
    if (1 == 2)
    {
      x26 = 100;
    }
  }*/
  /*
  // PRUEBAS CON CHAR
  char a;

  a = 255;
  // a++;
  // char + int = int -> Error
  a = 1;
  int b = 2;
  // a = a + b; //Error
  a = (char)(a + b); // Bien

  // char + float = float -> Error
  a = 1;
  float c = 3;
  // a = a + c; //Error
  // a = (int) (a + c); //Error
  a = (char)(a + c); // Bien

  // char + char = char -> Bien
  a = 1;
  char d = 4;
  a = a + d;

  // PRUEBAS CON INT
  int e = 256;

  // int + char = int -> Bien
  char f = 2;
  e = e + f; // Bien

  // int + float = float -> Error
  e = 256;
  float g = 5;
  // e = e + g; // Error
  e = (int)(e + g); // Bien

  // int + int = int -> Bien
  e = 256;
  int h = 2;
  e = e + h;         // Bien
  e = (char)(e + h); // Bien*()
  */
